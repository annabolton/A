# 📝 Academic Paper Reviewer

This Streamlit app analyzes scientific papers for structure, rigor, citations, and more — following peer-review guidelines.

## Features
- Section completeness scoring
- Methodology rigor analysis
- Citation and diversity check
- Research gap detection
- Peer review checklist evaluation
- PDF feedback export

## Setup

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy on Streamlit Cloud
1. Fork this repo
2. Go to [streamlit.io/cloud](https://streamlit.io/cloud)
3. Link your repo and deploy!
